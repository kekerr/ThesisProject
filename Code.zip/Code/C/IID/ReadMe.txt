Design of Region Merging Algorithm for Segmentation of Noisy Images
By: Darcie Dillion, Katharine Kerr and Sungbok Lee

i.i.d. Region Merging Algorithm

To run set the neccessary parameters in the main.c file
The .txt file outputed from the MATLAB code must be in 
the same folder as the C code. 

The code can either stop merging when:
1. The image has been merged a specific number of times, or
2. The stopping criterion are met (aka a maximum merging cost
or there are only three remaining regions in the image).