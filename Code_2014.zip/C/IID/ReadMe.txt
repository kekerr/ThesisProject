Design of Region Merging Algorithm for Segmentation of Noisy Images
By: Darcie Dillion, Katharine Kerr and Sungbok Lee

i.i.d. Region Merging Algorithm
Note: This algorithm only works on macintosh computers. 

To run set the neccessary parameters in the main.c file
The .txt file outputed from the MATLAB code must be in 
the same folder as the C code. 

The code can either stop merging when:
1. The image has been merged a specific number of times, or
2. The stopping criterion are met (aka a maximum merging cost
or there are only three remaining regions in the image).

Unfortunately due to time constraints the code is not that 
beautiful; however, it does run! I've tried to provide
comments so that the code is still understandable. 