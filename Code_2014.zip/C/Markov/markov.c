#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "structures.h"
#include "markov.h"
#include "printing.h"

extern int BINSIZE;
extern int QUANT;
extern int MAXMERGE;
extern int IHEIGHT;
extern int IWIDTH;

//calculates the empirical distribution
double *calcEmpiricalDist(int x, int y, int height, int width, int pixels[IHEIGHT][IWIDTH], double *empirDist){
	int pix;
	int bin;
	int i,j;
	double delta = 256/QUANT;
	//Quantization Code for grey scale:
	for(i=y; i<(y+height); i++) {
		for (j=x; j<(x+width); j++) {
			pix = pixels[i][j];
			bin = floor(pix/delta);
			empirDist[bin]++;
		}
	}

	for(i=0; i<QUANT; i++) {
		empirDist[i] = empirDist[i] / (height*width);
	}
	return empirDist;
}

//calculates the merging criterion
double calcMergingCriterion(double *empir, double **transition, double n, double *nempir, double **ntransition, double nn){
	double mergingCriterion;
	double jointTrans[QUANT][QUANT];
	double dempir;
	double dnempir;
	double sum = n + nn;
	double check;
	int i, j;
	for(i=0; i<QUANT; i++){
		for(j=0; j<QUANT; j++) {
			jointTrans[i][j] = (n/sum)*transition[i][j] + (nn/sum)*ntransition[i][j];
		}
	}
	dempir = KLDivergence(empir, transition, jointTrans);
	dnempir = KLDivergence(nempir, ntransition, jointTrans);
	mergingCriterion = n*dempir + nn*dnempir;
	return mergingCriterion;
}

//calcualtes the divergence between two regions
double KLDivergence(double *empir, double **trans, double jointtrans[QUANT][QUANT]){
	double kldivergence = 0;
	double term;
	int i,j;
	for(i=0; i<QUANT; i++) {
		for(j=0; j<QUANT; j++){
			//can't divide by zero!
			if(jointtrans[i][j] < 0.0001 && trans[i][j] < 0.0001){
				//do nothing
			}else {
				if(trans[i][j] == 0) {
					//do nothing
				} else {
					term = empir[i]*trans[i][j]*log2(trans[i][j]/jointtrans[i][j]);
					kldivergence = kldivergence + term;
				}
			}
		}
	}
	return kldivergence;
}

//calculates the transition matrix
double **calcTransitionM(int x, int y, int height, int width, int pixels[IHEIGHT][IWIDTH], double **transitionM){
	int pix1, pix2;
	int bin1, bin2;
	int i,j;
	double delta = 256/QUANT;

	//Transition matrix for quantized grey scaled image, looking only at right direction
	for(i=y; i<(y+height); i++) {
		for (j=x; j<(x+width-1); j++) {
			pix1 = pixels[i][j];
			pix2 = pixels[i][j+1];
			bin1 = floor(pix1/delta);
			bin2 = floor(pix2/delta);
			transitionM[bin1][bin2]++;
		}
	}

	for(i=0; i<QUANT; i++) {
		for(j=0; j<QUANT; j++) {
			transitionM[i][j] = transitionM[i][j] / (height*(width-1));
		}
	}
	return transitionM;
}
