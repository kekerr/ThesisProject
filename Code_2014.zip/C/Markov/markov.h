extern int IWIDTH;
extern int IHEIGHT;
extern int QUANT;


/* All Functions pertaining to calculating according to IID model */

//calculating merging criterion for Markov
//int calcMergingCriterion(struct region *r1, struct region *r2);
double *calcEmpiricalDist(int x, int y, int height, int width, int pixles[IHEIGHT][IWIDTH], double *empirDist);
double calcMergingCriterion(double *empir, double **transition, double n, double *nempir, double **ntransition, double nn);
double KLDivergence(double *empir, double **trans, double jointtrans[QUANT][QUANT]);
double **calcTransitionM(int x, int y, int height, int width, int pixels[IHEIGHT][IWIDTH], double **transitionM);
