void printI2D(int **A, int width, int height);
void printD1D(double *A, int size);
void printD2D(double **A, int width, int height);
void printI1D(int *A, int size);
void printNeighbours(Regionptr r1);
void printRegions(int *remainingRegions, int numAtoms, Imageptr image);
